import java.util.Scanner;

public class CalcSpeed {

    @FunctionalInterface
    private interface Speed <T>{
        T speed(T distance,T time);
    }

    public static void main(String[] args) {

        Speed s = (distance,time)->{
            return (Double)distance/(Integer)time;
        };

        System.out.print("Enter The Distance(in km) to travel: ");
        Double distance = new Scanner(System.in).nextDouble();

        System.out.print("Enter The estimated time(in Hours) to travel: ");
        Integer time = new Scanner(System.in).nextInt();

        System.out.println("Your speed should be: "+s.speed(distance,time)+"km/h");

    }
}

