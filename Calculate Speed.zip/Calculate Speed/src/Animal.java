
public enum Animal{

    Cat(15,"Tom"),Dog,Pig,Mouse;


    private int age;
    private String aName;

    private Animal(){
        age=5;
        aName=this.name();
    }
    private Animal(int age, String name) {

        this.age=age;
        this.aName=name;
    }

    public String getaName() {
        return aName;
    }

    public void setaName(String aName) {
        this.aName = aName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }


}
